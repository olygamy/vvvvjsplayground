See <https://github.com/mishoo/UglifyJS>.
